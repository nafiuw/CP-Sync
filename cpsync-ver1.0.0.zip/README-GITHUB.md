# CP Sync

Push your accepted submissions from Codeforces, CodeChef, LeetCode, NeetCode, HackerRank, vJudge, AtCoder, GeeksforGeeks, and CSES straight into a GitHub repository. Solve a problem, get Accepted, and the code is committed automatically, organized by platform and difficulty.

No copy-pasting, no remembering to update your repo at the end of the day, no losing track of what you've solved where.

```
your-repo/
  codeforces/
    1500-1599/
      1873A.cpp
  leetcode/
    Medium/
      two-sum.py
  codechef/
    500-599/
      LUCKYSEVEN.cpp
  atcoder/
    1200-1299/
      abc321_a.cpp
  geeksforgeeks/
    School/
      max-subarray-sum.cpp
  cses/
    Introductory-Problems/
      weird-algorithm.cpp
  hackerrank/
  vjudge/
  neetcode/
```

## Features

- **Automatic detection** on Codeforces, CodeChef, LeetCode, HackerRank, AtCoder, vJudge, GeeksforGeeks, and CSES - solve a problem, and the accepted code lands in your repo within a few seconds.
- **Manual Push with autofill** for anything auto-detection misses, or for judges not built in yet. One click reads the problem name, link, and difficulty off the current tab; paste your code and push.
- **Duplicate-safe.** Resubmitting an identical solution doesn't create a pointless commit - code is hashed and compared against what's already in the repo.
- **Streak tracking, push history, and retry.** The popup shows your current streak and total synced, keeps a log of every push, and retries failed ones with backoff.
- **Custom commit messages, folder rules, and language handling** - configurable per your workflow, not hardcoded.
- **Everything stays local.** Your GitHub token lives in Chrome's storage and is never sent anywhere but the GitHub API.

## Installation

CP Sync isn't on the Chrome Web Store yet, so it installs as an unpacked extension:

1. Download or clone this repository.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the project folder.
4. Pin the extension so it's easy to reach.

Works in any Chromium-based browser (Chrome, Edge, Brave) on version 111 or later.

## Setup

1. Create a [fine-grained personal access token](https://github.com/settings/tokens?type=beta) scoped to the repository you want to push into, with **Contents: Read and write** permission.
2. Open the extension popup, paste the token, your GitHub username, and the repo name.
3. Hit **Test Connection** to confirm it's wired up, then **Save Settings**.
4. Pick which platforms you want synced.

That's it. Go solve something.

## How it works

Each supported judge gets its own detection strategy, since none of them expose a public API built for this kind of thing:

| Platform | Approach |
|---|---|
| Codeforces | Watches your submissions table for a resolved verdict, pulls the source from the submission page |
| LeetCode | Reads the result banner, fetches your code from LeetCode's own submissions endpoint |
| CodeChef | Detects the various "solved" messages CodeChef shows, then reads the code out of the on-page editor |
| AtCoder | Tracks your most recent resolved submission and pulls the source from the detail page |
| HackerRank | Detects a pass, fetches the submission record for the actual code |
| vJudge | Watches the status table for an accepted run and fetches the stored solution |
| GeeksforGeeks | Detects the verdict message and reads the code out of the on-page editor |
| CSES | Reads the verdict and code directly off the submission result page |
| NeetCode | Logs completions from the checklist (NeetCode isn't a judge itself - pair with the LeetCode detector for real code) |

Every detector runs entirely client-side inside your browser. Nothing is sent anywhere except the final commit, which goes straight to GitHub over their REST API.

## Manual Push

Auto-detection can't cover everything - a judge might change its layout, or you might be using something not on the list. Manual Push handles both:

- **Autofill** reads whatever's on your current tab and fills in the problem name, link, and difficulty.
- Paste your code, pick a language (including a free-text "Other" option), and push.
- Works for any judge - pick "Other / Custom Judge" and name it yourself.

## Limitations

- Not published on the Chrome Web Store, so it has to be loaded as an unpacked extension for now. (Gonna Publish It ASAP)
- Detection depends on each site's current markup and internal endpoints. A redesign on any of these platforms can break detection until the extension is updated to match. (In Case Any Site Stops Pushing You Can Just Use MANUAL PUSH function)
- NeetCode support only tracks completion, not code, since NeetCode doesn't run submissions itself.
- Rating and difficulty extraction is best-effort where a platform doesn't expose it cleanly.

## Contributing

Pull requests are welcome, especially for judges with fragile detection or ones not yet supported. If you're fixing a detector that broke, include what changed on the site's end so the fix is easy to follow later.

## License

MIT - see [LICENSE](LICENSE).

---

Copyright (c) 2026 nafiuw_nebir
