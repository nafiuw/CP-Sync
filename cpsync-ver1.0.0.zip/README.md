# CP Sync - push Accepted submissions straight to GitHub

> **Updating from a previous version?** Content scripts only get replaced in
> a tab once that tab is fully reloaded - reloading the extension in
> `chrome://extensions` alone does NOT update tabs you already had open.
> After updating: (1) go to `chrome://extensions`, click the refresh icon
> on the CP Sync card, then (2) hard-refresh (Ctrl+Shift+R / Cmd+Shift+R)
> every judge tab you're testing in, or just close and reopen them.
>
> **How to confirm you're actually on the current version:** every content
> script now logs its version number as part of the "watching" line, e.g.
> `[CP Sync] v1.0.0 watching CodeChef submissions on this frame: ...`. Check
> that number against the `version` field in `manifest.json` in this zip -
> if they don't match (or the log is missing the version number entirely),
> you're testing stale code and need to reload as described above.

A browser extension that watches Codeforces, CodeChef, LeetCode, NeetCode,
HackerRank, vJudge, AtCoder, GeeksforGeeks, and CSES for **Accepted**
submissions and automatically commits the code to a GitHub repo, organized
like:

```
your-repo/
  codeforces/
    1500-1599/
      1873A.cpp
  leetcode/
    Medium/
      two-sum.py
  codechef/
    Practice/
      FLOW001.cpp
  atcoder/
    abc321/
      A.cpp
  geeksforgeeks/
    School/
      max-subarray-sum.cpp
  cses/
    Introductory-Problems/
      weird-algorithm.cpp
  hackerrank/
  vjudge/
  neetcode/
```

## 1. Install the extension (unpacked)

1. Open `chrome://extensions` (or `edge://extensions`, or `brave://extensions`).
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and select this folder.
4. Pin the extension so you can reach its settings quickly.

## 2. Create a GitHub token

1. Go to [github.com/settings/tokens?type=beta](https://github.com/settings/tokens?type=beta)
   and create a **fine-grained personal access token**.
2. Scope it to the one repository you want submissions pushed to.
3. Under **Repository permissions**, set **Contents: Read and write**.
4. Copy the token - you won't see it again.

## 3. Configure the extension

1. Click the extension icon.
2. Paste your token, your GitHub username/org, and the repo name
   (e.g. `owner = you`, `repo = competitive-programming`).
3. Set the branch (defaults to `main`).
4. Pick which platforms you want to sync, click **Save Settings**, then
   **Test Connection** to confirm everything's wired up correctly.

## 4. Solve problems as normal

Solve on any supported site - the extension polls the page in the
background. When it sees an Accepted verdict, it fetches your source and
pushes a commit named `Solved: <problem> (<platform>)`.

You'll get a small OS notification confirming success or telling you if a
push failed (usually a token/permission issue).

## How detection works per platform (and where it might break)

Every competitive-programming site is a moving target - none of them offer
a stable, documented "give me my Accepted code" API for third parties, so
this extension leans on page-scraping and network-request interception.
**If a site redesigns its UI, the corresponding content script may need a
selector update.** 

**A note on NeetCode specifically:** if your NeetCode account has its own built-in GitHub sync option (some accounts/plans do, under account or integration settings), use that directly.


## Extra features

- **Autofill / Clear All** - in Manual Push, click **Autofill** to read the problem name, link, ID, and rating/difficulty straight off whichever judge page is open in your active tab (Competitive-Companion style) - then just paste your code and push. **Clear All** wipes the whole form (and its saved draft) back to defaults in one click. Autofill works out of the box on all seven built-in judges since they're already covered by this extension's host permissions; for a fully custom/unlisted judge it depends on how the popup was opened and may need the fields filled in by hand.
- **Custom language** - the Language dropdown in Manual Push includes C plus an "Other" option with a free-text field, for any language not in the preset list.
- **Pop out to a tab** - clicking the extension icon opens a transient popup, which Chrome closes the instant it loses focus (e.g. clicking another tab to copy a problem name) - this is standard browser behavior for all extension popups, not something an extension can override. Click **Open in tab** in the header to reopen the same UI as a normal persistent browser tab that stays open regardless of focus changes; use this for Manual Push sessions where you need to alt-tab around.
- **Manual Push autosave** - every field in Manual Push is saved to local storage on every keystroke and restored automatically, whether you're in the popup or the tab. Nothing is lost even if the popup does close on you; only a successful push clears the per-problem fields (platform/language selections are kept for the next entry).
- **Remembers your last tab** - reopening the popup returns you to whichever tab (General/Manual Push/History/Advanced) you were last on.
- **Manual Push tab** - when auto-detection misses a submission (or you're
  backfilling old solutions), paste platform/problem/code by hand and it
  goes through the exact same GitHub push pipeline.
- **Streak & stats strip** - the popup header shows your current daily
  streak, total problems synced, and anything still pending retry. The
  extension icon badge also shows your live streak count.
- **History tab** - every push (success, failure, or skipped-as-duplicate)
  is logged locally with a timestamp and the exact repo path it went to.
  Failed pushes can be retried in one click from here.
- **Duplicate detection** - before committing, the code is hashed (SHA-256)
  and compared against what's already at that path. Resubmitting an
  identical accepted solution won't create a no-op commit. Turn this off
  in **Advanced** if you'd rather always overwrite.
- **Automatic retry with backoff** - transient GitHub 5xx errors are
  retried with exponential backoff; if you hit GitHub's rate limit, the
  push is queued and surfaced in the "pending retry" counter instead of
  silently failing.
- **Custom commit messages** - set your own template in **Advanced** using
  `{problem}`, `{platform}`, `{contest}`, `{rating}`, `{language}`.
- **Settings export/import** - back up your configuration (repo, branch,
  enabled platforms, commit template) as JSON. Your GitHub token is
  deliberately excluded from exports so you don't accidentally leak it.


## Permissions used

- `storage` - save your GitHub token/settings locally (`chrome.storage.sync`)
- `host_permissions` for each judge site - read submission pages
- `host_permissions` for `api.github.com` - push commits
- `notifications` - success/failure toasts
