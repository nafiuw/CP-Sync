// content_scripts/cses.js
//
// CSES redirects you to a submission result page after you submit
// (.../problemset/result/{id}/), which shows the verdict (ACCEPTED, WRONG
// ANSWER, etc.) and - unlike most judges - displays your submitted source
// directly on that same page, no separate fetch needed. 
//
// CONFIDENCE NOTE: exact class names on CSES's result page are a best
// effort without a live look at the current site. If code capture comes
// back empty, the console will show every <pre> element's length so we
// can see whether the code was found under a different one than expected.

(function () {
  console.log("[CP Sync] v" + chrome.runtime.getManifest().version + " watching CSES submissions on this page:", location.pathname);

  try {
    const badge = document.createElement("div");
    badge.textContent = "CP Sync v" + chrome.runtime.getManifest().version + " watching CSES";
    badge.style.cssText =
      "position:fixed;bottom:8px;right:8px;z-index:2147483647;background:#238636;color:#fff;" +
      "padding:4px 9px;border-radius:6px;font:11px/1.4 sans-serif;opacity:0.9;pointer-events:none;";
    document.documentElement.appendChild(badge);
    setTimeout(() => badge.remove(), 10000);
  } catch (e) {}

  const CHECK_INTERVAL_MS = 1500;
  let scanCount = 0;

  function isResultPage() {
    return /\/problemset\/result\/\d+/.test(location.pathname);
  }

  function getSubmissionId() {
    const m = location.pathname.match(/\/problemset\/result\/(\d+)/);
    return m ? m[1] : null;
  }

  function isAcceptedVisible(bodyText) {
    return /\bACCEPTED\b/.test(bodyText);
  }

  function getCode() {
    const pres = Array.from(document.querySelectorAll("pre"));
    if (!pres.length) return null;
    let best = pres[0];
    for (const p of pres) {
      if ((p.textContent || "").length > (best.textContent || "").length) best = p;
    }
    return best.textContent || null;
  }

  function getProblemMeta() {
    const taskLink = document.querySelector('a[href*="/problemset/task/"]');
    const problemName = taskLink ? taskLink.textContent.trim() : (document.title || "problem").trim();
    const taskIdMatch = taskLink ? taskLink.href.match(/\/task\/(\d+)/) : null;
    const problemId = taskIdMatch ? taskIdMatch[1] : getSubmissionId();

    const sectionLink = document.querySelector('a[href*="/problemset/"][href*="#"], nav a, .nav a');
    const section = sectionLink && !sectionLink.href.includes("/task/") ? sectionLink.textContent.trim() : null;

    return { problemName, problemId, section };
  }

  async function scan() {
    if (!isResultPage()) return;

    const submissionId = getSubmissionId();
    if (!submissionId) return;

    const dedupeKey = "cpsync_cses_" + submissionId;
    if (sessionStorage.getItem(dedupeKey)) return;

    const bodyText = document.body.innerText || "";
    const accepted = isAcceptedVisible(bodyText);

    scanCount++;
    if (scanCount <= 10) {
      const pres = Array.from(document.querySelectorAll("pre"));
      console.warn(
        "[CP Sync] CSES scan #" + scanCount + ": accepted text present:", accepted,
        "- <pre> elements found:", pres.length, "- lengths:", pres.map((p) => (p.textContent || "").length)
      );
    }

    if (!accepted) return;

    sessionStorage.setItem(dedupeKey, "1");

    const meta = getProblemMeta();
    const code = getCode();

    console.log("[CP Sync] pushing CSES submission", submissionId, meta.problemName, "- code captured:", !!code);

    chrome.runtime.sendMessage({
      type: "CP_SYNC_SOLVED",
      payload: {
        platform: "cses",
        problemName: meta.problemName,
        problemId: meta.problemId,
        rating: null,
        contest: meta.section,
        language: "",
        code: code || "// source not captured automatically - open the result page and copy it manually",
        url: location.href,
        verdict: "ACCEPTED"
      }
    });
  }

  setInterval(scan, CHECK_INTERVAL_MS);
  scan();
})();
