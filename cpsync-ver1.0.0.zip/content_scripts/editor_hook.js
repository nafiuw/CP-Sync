// content_scripts/editor_hook.js
//
// Declared with "world": "MAIN" in manifest.json (not injected via a
// <script> tag, so it isn't blocked by the page's CSP). Some judges
// (CodeChef's newer practice UI, NeetCode's in-browser editor) show an
// Accepted/Correct message without ever exposing a separate "view
// solution" page - the only place your code exists is live in the editor
// on screen. This script knows how to read that, whichever editor
// component the page happens to use, and hands it back to the isolated-
// world content script (codechef.js / neetcode.js) via postMessage.
//
// This file has NO access to chrome.runtime - it only talks back via
// window.postMessage.

(function () {
  if (window.__cpSyncEditorHookInstalled) return;
  window.__cpSyncEditorHookInstalled = true;

  // Some judges have OTHER editor-like components on the page that aren't
  // your actual solution: a chat/help widget (CodeChef's "AI Tutor"), a
  // keyword/snippet cheat-sheet sidebar (plausible on a "Basic Programming
  // Concepts" course page), a hint panel, etc. Reading "whichever editor
  // is largest" without excluding these can grab the wrong one entirely.
  function isExcluded(el) {
    if (!el || typeof el.closest !== "function") return false;
    return !!el.closest(
      '[class*="tutor" i], [id*="tutor" i], [class*="assistant" i], [id*="assistant" i], ' +
      '[class*="chat" i], [id*="chat" i], [class*="copilot" i], [id*="copilot" i], ' +
      '[class*="reference" i], [id*="reference" i], [class*="cheatsheet" i], [id*="cheatsheet" i], ' +
      '[class*="cheat-sheet" i], [id*="cheat-sheet" i], [class*="keyword" i], [id*="keyword" i], ' +
      '[class*="snippet-list" i], [id*="snippet-list" i], [class*="helper" i], [id*="helper" i], ' +
      '[class*="hint" i], [id*="hint" i], [class*="suggest-widget" i], [class*="hover-widget" i]'
    );
  }

  // Excluding the wrong thing entirely (leaving zero candidates) is worse
  // than including a slightly-risky one - the garbage filter in pickBest()
  // still catches genuinely bad content downstream. If exclusion would
  // wipe out every candidate on a page that DID have at least one, retry
  // without it instead of coming back with nothing.
  function filterWithFallback(nodes, label) {
    const filtered = nodes.filter((n) => !isExcluded(n));
    if (filtered.length || !nodes.length) return filtered;
    console.log(
      "[CP Sync] editor_hook:", label, "- exclusion filter removed all", nodes.length,
      "candidate(s); retrying without it since there's nothing else to try"
    );
    return nodes;
  }

  // Candidates whose container looks like the ACTUAL solution editor get
  // priority over "just pick whichever is longest" once we have more than
  // one option left.
  function looksLikeRealEditor(el) {
    if (!el || typeof el.closest !== "function") return false;
    return !!el.closest(
      '[class*="solution" i], [id*="solution" i], [class*="code-editor" i], [id*="code-editor" i], ' +
      '[class*="ide" i], [id*="ide" i], [data-testid*="editor" i]'
    );
  }

  // A long run of the exact same character is never real source code -
  // it's the signature of an internal measurement/accessibility buffer
  // (Monaco and CodeMirror both keep hidden input elements for IME/screen
  // reader support that can contain padded, repeated, or partial content
  // rather than your actual code). Treat anything matching this as
  // invalid rather than risk committing it.
  //
  // IMPORTANT: only flag repeated NON-whitespace characters. Deeply
  // indented real code (e.g. 16+ spaces at a 4-level nested loop, or tabs)
  // legitimately contains long runs of the same whitespace character -
  // that's normal formatting, not garbage, and was being wrongly rejected.
  function looksLikeGarbage(text) {
    if (!text) return true;
    if (/([^\s])\1{14,}/.test(text)) return true;
    return false;
  }

  function pickBest(candidates) {
    // candidates: [{ el, value }]
    const valid = candidates.filter((c) => c.value && !looksLikeGarbage(c.value));
    if (!valid.length) return null;

    const realEditorCandidates = valid.filter((c) => looksLikeRealEditor(c.el));
    const pool = realEditorCandidates.length ? realEditorCandidates : valid;

    let best = pool[0];
    for (const c of pool) {
      if (c.value.length > best.value.length) best = c;
    }
    return best.value;
  }

  function readMonaco() {
    try {
      if (!window.monaco || !window.monaco.editor) return null;

      if (typeof window.monaco.editor.getEditors === "function") {
        const allEditors = window.monaco.editor.getEditors();
        const allowedNodes = filterWithFallback(allEditors.map((ed) => ed.getDomNode()), "Monaco editors");
        const editors = allEditors.filter((ed) => allowedNodes.includes(ed.getDomNode()));
        const candidates = editors.map((ed) => ({ el: ed.getDomNode(), value: ed.getValue() || "" }));
        const result = pickBest(candidates);
        if (result) return result;
      }

      // Fallback: bare models, no DOM filtering possible - only used if
      // getEditors() wasn't available or returned nothing usable.
      const models = window.monaco.editor.getModels();
      if (models && models.length) {
        const candidates = models.map((m) => ({ el: null, value: m.getValue() || "" }));
        const valid = candidates.filter((c) => c.value && !looksLikeGarbage(c.value));
        if (valid.length) {
          let best = valid[0];
          for (const c of valid) if (c.value.length > best.value.length) best = c;
          return best.value;
        }
      }
    } catch (e) {}
    return null;
  }

  function readCodeMirror() {
    try {
      const allNodes = Array.from(document.querySelectorAll(".CodeMirror"));
      const nodes = filterWithFallback(allNodes, "CodeMirror nodes");
      const candidates = nodes
        .map((node) => {
          const cm = node.CodeMirror;
          return cm && typeof cm.getValue === "function" ? { el: node, value: cm.getValue() || "" } : null;
        })
        .filter(Boolean);
      return pickBest(candidates);
    } catch (e) {
      return null;
    }
  }

  function readAceFromRenderedDOM(node) {
    // Reads Ace's own rendered text layer instead of going through its JS
    // API - works even when the editor instance isn't reachable (common
    // with React wrappers like react-ace, which don't reliably attach the
    // standard .env property the plain Ace API depends on). Ace renders
    // each source line as a ".ace_line" element inside the text layer, in
    // document order, so joining them reconstructs the visible code.
    try {
      const lines = Array.from(node.querySelectorAll(".ace_line"));
      if (!lines.length) return null;
      return lines.map((l) => l.textContent).join("\n");
    } catch (e) {
      return null;
    }
  }

  function readAce() {
    try {
      const allNodes = Array.from(document.querySelectorAll(".ace_editor"));
      const nodes = filterWithFallback(allNodes, "Ace nodes");
      const candidates = [];
      for (const node of nodes) {
        let value = null;
        try {
          if (node.env && node.env.editor && typeof node.env.editor.getValue === "function") {
            value = node.env.editor.getValue();
          } else if (window.ace && typeof window.ace.edit === "function") {
            value = window.ace.edit(node).getValue();
          }
        } catch (e) {}
        if (!value) value = readAceFromRenderedDOM(node);
        if (value) candidates.push({ el: node, value });
      }
      return pickBest(candidates);
    } catch (e) {
      return null;
    }
  }

  function readTextarea() {
    try {
      // Monaco, CodeMirror, and Ace all keep their own hidden <textarea>
      // for keyboard input / IME / screen-reader support - these do NOT
      // contain your full code (often just a small window around the
      // cursor, sometimes padded with extra characters), so they must be
      // excluded here. Real content from those editors should already
      // have been read via their dedicated APIs above; this fallback is
      // only for a genuinely plain <textarea>-based editor.
      const areas = Array.from(document.querySelectorAll("textarea")).filter(
        (area) => !isExcluded(area) && !area.closest(".monaco-editor") && !area.closest(".CodeMirror") && !area.closest(".ace_editor")
      );
      const candidates = areas.map((area) => ({ el: area, value: area.value || "" }));
      return pickBest(candidates);
    } catch (e) {
      return null;
    }
  }

  function readCurrentCode() {
    return readMonaco() || readCodeMirror() || readAce() || readTextarea() || null;
  }

  function diagnosticSnapshot() {
    const snap = {
      hasMonacoGlobal: !!(window.monaco && window.monaco.editor),
      monacoEditorsCount: 0,
      monacoModelsCount: 0,
      codeMirrorNodeCount: document.querySelectorAll(".CodeMirror").length,
      aceNodeCount: document.querySelectorAll(".ace_editor").length,
      aceHasEnvProperty: false,
      aceNodeWasExcluded: false,
      hasAceGlobal: !!(window.ace && typeof window.ace.edit === "function"),
      aceLineElementCount: document.querySelectorAll(".ace_line").length,
      textareaCount: document.querySelectorAll("textarea").length
    };
    try {
      if (window.monaco && window.monaco.editor) {
        if (typeof window.monaco.editor.getEditors === "function") {
          snap.monacoEditorsCount = window.monaco.editor.getEditors().length;
        }
        if (typeof window.monaco.editor.getModels === "function") {
          snap.monacoModelsCount = window.monaco.editor.getModels().length;
        }
      }
      const aceNode = document.querySelector(".ace_editor");
      if (aceNode) {
        snap.aceHasEnvProperty = !!(aceNode.env && aceNode.env.editor);
        snap.aceNodeWasExcluded = isExcluded(aceNode);
      }
    } catch (e) {}
    return snap;
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.source !== "cpsync" || msg.type !== "CPSYNC_REQUEST_CODE") return;

    const snap = diagnosticSnapshot();
    const code = readCurrentCode();
    console.log(
      "[CP Sync] v2.6.0 editor_hook diagnostic on", location.href, "-",
      "Monaco global:", snap.hasMonacoGlobal, "editors:", snap.monacoEditorsCount, "models:", snap.monacoModelsCount,
      "- CodeMirror nodes:", snap.codeMirrorNodeCount,
      "- Ace nodes:", snap.aceNodeCount, "Ace .env found:", snap.aceHasEnvProperty, "Ace excluded:", snap.aceNodeWasExcluded,
      "Ace global:", snap.hasAceGlobal, "Ace .ace_line count:", snap.aceLineElementCount,
      "- textareas:", snap.textareaCount,
      "- captured code length:", code ? code.length : 0,
      "- preview:", code ? JSON.stringify(code.slice(0, 80)) : null
    );

    window.postMessage({ source: "cpsync", type: "CPSYNC_CODE_RESPONSE", requestId: msg.requestId, code }, "*");
  });
})();
