// content_scripts/geeksforgeeks.js
// NOTE: As CP Sync doesn't have a live, current view of GFG's exact DOM,
// so the verdict phrases and selectors below are best-effort. Every scan
// logs a `[CP Sync] v<version> watching GeeksforGeeks...` line immediately
// on load, and diagnostic warnings while waiting for a match - if it's not
// firing, check the console for those and the body-text snippet they
// print, and add whatever phrase is actually shown to ACCEPTED_KEYWORDS.

(function () {
  console.log("[CP Sync] v" + chrome.runtime.getManifest().version + " watching GeeksforGeeks submissions on this page:", location.href);

  const CHECK_INTERVAL_MS = 1200;
  let scanCount = 0;
  let alreadyPushedForThisView = false;

  const ACCEPTED_KEYWORDS = [
    "correct answer",
    "all test cases passed",
    "compiled and executed successfully",
    "congratulations",
    "problem solved successfully",
    "accepted"
  ];

  function normalizeForMatch(text) {
    return (text || "")
      .toLowerCase()
      .replace(/[\u2018\u2019\u02BC\u00B4`']/g, "")
      .replace(/[^a-z0-9\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function isAcceptedVisible(bodyText) {
    const normalized = normalizeForMatch(bodyText);
    return ACCEPTED_KEYWORDS.some((kw) => normalized.includes(kw));
  }

  function getProblemMeta() {
    const parts = location.pathname.split("/").filter(Boolean);
    // GFG URLs look like /problems/<slug>/1 or /problems/<slug>/0 - the
    // slug is whichever segment comes right after "problems".
    const idx = parts.indexOf("problems");
    const slug = idx >= 0 && parts[idx + 1] ? parts[idx + 1] : parts[parts.length - 1] || "problem";
    const titleEl = document.querySelector("h1, [class*='problem-title' i], [class*='problemTitle' i]");
    const title = titleEl
      ? titleEl.textContent.trim()
      : (document.title || slug).replace(/\s*[|-]\s*(Practice|GeeksforGeeks).*$/gi, "").trim();
    const diffEl = document.querySelector("[class*='difficulty' i]");
    const difficulty = diffEl ? diffEl.textContent.trim() : null;
    return { slug, title, difficulty };
  }

  function requestCodeFromLiveEditor(timeoutMs = 2000) {
    return new Promise((resolve) => {
      const requestId = Math.random().toString(36).slice(2);
      function handler(event) {
        if (event.source !== window) return;
        const msg = event.data;
        if (!msg || msg.source !== "cpsync" || msg.type !== "CPSYNC_CODE_RESPONSE" || msg.requestId !== requestId) return;
        window.removeEventListener("message", handler);
        clearTimeout(timer);
        resolve(msg.code || null);
      }
      window.addEventListener("message", handler);
      const timer = setTimeout(() => {
        window.removeEventListener("message", handler);
        resolve(null);
      }, timeoutMs);
      window.postMessage({ source: "cpsync", type: "CPSYNC_REQUEST_CODE", requestId }, "*");
    });
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // A single request can come back empty if the editor hasn't finished
  // initializing yet at the exact moment the verdict appears - retry a
  // few times with backoff instead of accepting the first null.
  async function requestCodeWithRetries(maxAttempts = 4) {
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const code = await requestCodeFromLiveEditor();
      if (code) {
        console.log("[CP Sync] GeeksforGeeks code capture succeeded on attempt", attempt);
        return code;
      }
      console.warn("[CP Sync] GeeksforGeeks code capture attempt", attempt, "returned nothing - retrying");
      if (attempt < maxAttempts) await sleep(800 * attempt);
    }
    return null;
  }

  // GFG's actual language menu: C(gcc 5.4), C++, Python 3,
  // Java(21), C#, Javascript(nodev22) - version numbers in parentheses
  // will drift over time, so match on the language name itself.
  const KNOWN_GFG_LANGUAGES = ["C++", "Python 3", "Python", "Java", "C#", "Javascript", "JavaScript", "C"];

  function detectLanguage() {
    // Check every <select> on the page first - if GFG's language picker is
    // a plain <select>, its currently chosen option is the most reliable
    // signal available.
    const selects = Array.from(document.querySelectorAll("select"));
    console.log(
      "[CP Sync] GeeksforGeeks language detection: found", selects.length, "<select> element(s):",
      selects.map((sel) => {
        const opt = sel.selectedOptions && sel.selectedOptions[0];
        return { selectedText: opt ? opt.textContent.trim() : null, value: sel.value, className: sel.className };
      })
    );

    for (const sel of selects) {
      const opt = sel.selectedOptions && sel.selectedOptions[0];
      const text = ((opt ? opt.textContent : "") || sel.value || "").trim();
      if (text && KNOWN_GFG_LANGUAGES.some((l) => text.includes(l))) return text;
    }

    const candidates = [
      document.querySelector('[class*="language" i] option[selected]'),
      document.querySelector('select[class*="language" i]'),
      document.querySelector('[class*="lang-select" i]'),
      document.querySelector('[class*="language-dropdown" i]'),
      document.querySelector('button[class*="language" i]'),
      document.querySelector('[data-testid*="language" i]')
    ].filter(Boolean);

    for (const el of candidates) {
      const text = (el.textContent || el.value || "").trim();
      if (text) return text;
    }
    return "";
  }

  async function pushSolved() {
    if (alreadyPushedForThisView) return;
    alreadyPushedForThisView = true;

    const meta = getProblemMeta();
    const code = await requestCodeWithRetries();
    const language = detectLanguage();

    console.log(
      "[CP Sync] pushing GeeksforGeeks submission", meta.slug,
      "- code captured:", !!code, "- language:", language || "(not detected)",
      "- preview:", code ? JSON.stringify(code.slice(0, 80)) : null
    );

    chrome.runtime.sendMessage({
      type: "CP_SYNC_SOLVED",
      payload: {
        platform: "geeksforgeeks",
        problemName: meta.title,
        problemId: meta.slug,
        rating: meta.difficulty,
        contest: null,
        language,
        code: code || "// source not captured automatically - copy it from the editor and use Manual Push",
        url: location.href,
        verdict: "Accepted"
      }
    });
  }

  async function scan() {
    const bodyText = document.body.innerText || "";
    const accepted = isAcceptedVisible(bodyText);

    scanCount++;
    if (scanCount <= 15 && !accepted) {
      console.warn("[CP Sync] GeeksforGeeks scan #" + scanCount + ": accepted text present: false");
      console.warn("[CP Sync] GeeksforGeeks: body text snippet (first 300 chars):", bodyText.slice(0, 300));
    }
    if (accepted) {
      console.warn("[CP Sync] GeeksforGeeks: ACCEPTED TEXT DETECTED on scan #" + scanCount);
    }

    if (!accepted) {
      alreadyPushedForThisView = false;
      return;
    }

    await pushSolved();
  }

  setInterval(scan, CHECK_INTERVAL_MS);
  scan();
})();
